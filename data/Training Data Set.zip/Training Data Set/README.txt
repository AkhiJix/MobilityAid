Directory size was reduced from 500 to 200 due to presence of uncorrelated images in the directories.
The 200 images were properly curated such that no image has a blank background.
Benches are a little over fitted due to similar bench structure in the training images.
Trash Cans has 144 images since not many unique images were available for various kinds of trash cans which had a non-blank background.